Protipper = {};
local L = {};
Protipper.L = L;

L["CAST_NEXT"] = "Use me:"
L["ACQUIRE_TARGET"] = "Target an enemy."

if GetLocale() == "ptBR" then
end

if GetLocale() == "frFR" then
end

if GetLocale() == "deDE" then
end

if GetLocale() == "itIT" then
end

if GetLocale() == "koKR" then
end

if GetLocale() == "esMX" then
end

if GetLocale() == "ruRU" then
end

if GetLocale() == "zhCN" then
end

if GetLocale() == "esES" then
end

if GetLocale() == "zhTW" then
end